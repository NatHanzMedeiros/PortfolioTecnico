package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
EditText input;
TextView output;
int numeroGerado = 0;
int tentativas = 0;
Random gerador = new Random();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        input = findViewById(R.id.input);
        output = findViewById((R.id.output));

    }
    public void gerarnumero(View v){
        tentativas = 0;
        numeroGerado = gerador.nextInt(10) + 1;
        output.setText("Novo numero gerado  \uD83D\uDC4D\uD83c\uDFF8 ");
        input.setText("");


    }
    public void confirmar(View v) {
        int tentativa = Integer.parseInt(input.getText().toString());
        tentativas++;

        if (tentativa == numeroGerado) {
            output.setText("Parabéns você acertou em " + tentativas + " tentativas!");
        } else if (tentativa < numeroGerado) {
            output.setText("Dica de ouro! Tente um número maior! Tentativas restantes: " + (5 - tentativas));
        } else {
            output.setText("Dica de ouro! Tente um número menor! Tentativas restantes: " + (5 - tentativas));
        }
        if (tentativas == 5) {
            output.setText("Voce perdeu noob! O número era " + numeroGerado + ".");
        }
    }


}